@extends('candidate.layout.app')

@section('content')
<main class="app-main">
  <!-- Header -->
  <div class="app-content-header py-3 bg-white shadow-sm">
    <div class="container-fluid">
      <div class="row align-items-center">
        <div class="col-sm-6">
          <h4 class="mb-0">Chat</h4>
          <div class="text-muted small">Talking to <strong>{{ $user->name }}</strong></div>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end mb-0">
            <li class="breadcrumb-item"><a href="{{ route('candidate.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item active">Chat</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <!-- Content -->
  <div class="app-content">
    <div class="container-fluid py-3">
      <div class="row g-3">

        <!-- LEFT: Employer list -->
        <div class="col-lg-3">
          <div class="bg-white rounded-3 shadow-sm">
            <div class="p-3 border-bottom">
              <input type="text" id="chat-search" class="form-control form-control-sm" placeholder="Search employers...">
            </div>
            <div id="chat-user-list" class="list-group list-group-flush" style="max-height:75vh; overflow:auto;">
              @forelse($allEmployers as $emp)
                <a href="{{ route('candidate.candidateChat', $emp->id) }}"
                   class="list-group-item list-group-item-action d-flex align-items-center {{ $emp->id === $user->id ? 'active' : '' }}">
                  <div class="rounded-circle d-inline-flex justify-content-center align-items-center me-2"
                       style="width:38px;height:38px;background:#e6efff;">
                    <span class="fw-semibold">{{ strtoupper(substr($emp->name,0,1)) }}</span>
                  </div>
                  <div class="flex-grow-1">
                    <div class="fw-semibold">{{ $emp->name }}</div>
                    <div class="small text-muted">View conversation</div>
                  </div>
                </a>
              @empty
                <div class="p-3 text-muted small">No employers found.</div>
              @endforelse
            </div>
          </div>
        </div>

        <!-- RIGHT: Chat area -->
        <div class="col-lg-9">
          <div class="bg-white rounded-3 shadow-sm d-flex flex-column" style="height:75vh;">
            <!-- Conversation header -->
            <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
              <div class="d-flex align-items-center">
                <div class="rounded-circle d-inline-flex justify-content-center align-items-center me-2"
                     style="width:40px;height:40px;background:#e6efff;">
                  <span class="fw-semibold">{{ strtoupper(substr($user->name,0,1)) }}</span>
                </div>
                <div>
                  <div class="fw-semibold">{{ $user->name }}</div>
                  <div class="small text-muted">Employer</div>
                </div>
              </div>
            </div>

            <!-- Messages -->
            <div id="chat-box"
                 class="flex-grow-1 p-3"
                 style="background:#f7f8fa; overflow:auto;"
                 data-last-id="{{ $messages->last()->id ?? 0 }}">
              @foreach($messages as $msg)
                <div id="msg-{{ $msg->id }}"
                     class="mb-2 d-flex {{ $msg->from_user_id == auth()->id() ? 'justify-content-end' : 'justify-content-start' }}">
                  <div class="px-3 py-2 rounded-3 shadow-sm"
                       style="max-width:75%; {{ $msg->from_user_id == auth()->id() ? 'background:#3b82f6;color:#fff;' : 'background:#eef1f4;color:#111;' }}">
                    <div class="fw-normal">{!! nl2br(e($msg->message)) !!}</div>
                    <div class="small opacity-75 mt-1" style="font-size:11px;">
                      {{ $msg->created_at->format('h:i A') }}
                    </div>
                  </div>
                </div>
              @endforeach
            </div>

            <!-- Composer -->
            <form id="chat-form" class="p-3 border-top d-flex gap-2">
              @csrf
              <input type="hidden" name="to_user_id" value="{{ $user->id }}">
              <input type="text" name="message" class="form-control" placeholder="Type a message…" required autocomplete="off">
              <button type="submit" class="btn btn-primary px-4">Send</button>
            </form>
          </div>
        </div>

      </div>
    </div>
  </div>
</main>

{{-- Inline script specific to this page (keeps layout scripts clean) --}}
<script>
(function(){
  const chatBox = document.getElementById('chat-box');
  const chatForm = document.getElementById('chat-form');
  const searchInput = document.getElementById('chat-search');
  const MY_ID = {{ auth()->id() }};
  const PEER_ID = {{ $user->id }};
  // If your routes are named `send` / `fetch`, keep these.
  const SEND_URL  = "{{ route('send') }}";
  const FETCH_URL = "{{ route('fetch', $user->id) }}";

  // Track last loaded message id (from Blade)
  let lastMessageId = Number(chatBox.dataset.lastId || 0);

  // Helpers
  function nearBottom() {
    return (chatBox.scrollHeight - chatBox.scrollTop - chatBox.clientHeight) < 120;
  }
  function scrollToBottom() {
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function buildBubble(msg) {
    const isMine = (msg.from_user_id === MY_ID);
    const row = document.createElement('div');
    row.id = 'msg-' + msg.id;
    row.className = 'mb-2 d-flex ' + (isMine ? 'justify-content-end' : 'justify-content-start');

    const bubble = document.createElement('div');
    bubble.className = 'px-3 py-2 rounded-3 shadow-sm';
    bubble.style.maxWidth = '75%';
    bubble.style.background = isMine ? '#3b82f6' : '#eef1f4';
    bubble.style.color = isMine ? '#fff' : '#111';

    const text = document.createElement('div');
    text.className = 'fw-normal';
    text.innerHTML = (msg.message || '').replace(/\n/g,'<br>');

    const ts = document.createElement('div');
    ts.className = 'small opacity-75 mt-1';
    ts.style.fontSize = '11px';
    // prefer server timestamp if string; otherwise, fallback to now
    const when = msg.created_at ? new Date(msg.created_at) : new Date();
    ts.textContent = when.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });

    bubble.appendChild(text);
    bubble.appendChild(ts);
    row.appendChild(bubble);
    return row;
  }

  // Send
  chatForm.addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(chatForm);
    const wasNearBottom = nearBottom();

    fetch(SEND_URL, {
      method: 'POST',
      headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
      body: formData
    })
    .then(r => r.json())
    .then(msg => {
      // Guard: if server doesn’t return id/created_at, still append safely
      if (!document.getElementById('msg-' + msg.id)) {
        chatBox.appendChild(buildBubble(msg));
        lastMessageId = msg.id || lastMessageId; // update when available
        if (wasNearBottom) scrollToBottom();
      }
      chatForm.reset();
    });
  });

  // Poll only new messages (no duplicates)
  function poll() {
    fetch(FETCH_URL + '?after_id=' + encodeURIComponent(lastMessageId))
      .then(r => r.json())
      .then(list => {
        if (!Array.isArray(list)) return;
        const wasNearBottom = nearBottom();
        list.forEach(msg => {
          if (!document.getElementById('msg-' + msg.id)) {
            chatBox.appendChild(buildBubble(msg));
            lastMessageId = Math.max(lastMessageId, Number(msg.id || 0));
          }
        });
        if (wasNearBottom) scrollToBottom();
      })
      .catch(()=>{ /* ignore transient errors */ });
  }
  // Start polling
  const interval = setInterval(poll, 3000);
  // Initial autoscroll
  scrollToBottom();

  // Sidebar search (client-side filter)
  if (searchInput) {
    searchInput.addEventListener('input', function(){
      const q = this.value.trim().toLowerCase();
      document.querySelectorAll('#chat-user-list .list-group-item').forEach(a => {
        const name = a.textContent.trim().toLowerCase();
        a.style.display = name.includes(q) ? '' : 'none';
      });
    });
  }

  // Optional: clear interval on page unload
  window.addEventListener('beforeunload', () => clearInterval(interval));
})();
</script>
@endsection
