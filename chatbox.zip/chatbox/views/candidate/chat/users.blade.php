@extends('candidate.layout.app')

@section('content')
<main class="app-main">
  <!-- Header -->
  <div class="app-content-header py-3 bg-white shadow-sm">
    <div class="container-fluid">
      <div class="row align-items-center">
        <div class="col-sm-6">
          <h4 class="mb-0">Chat</h4>
          <div class="text-muted small">Choose an employer to start chatting</div>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end mb-0">
            <li class="breadcrumb-item"><a href="{{ route('candidate.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item active">Chat</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <!-- Content -->
  <div class="app-content">
    <div class="container-fluid py-3">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
          <div class="bg-white rounded-3 shadow-sm">
            <!-- Top bar -->
            <div class="p-3 border-bottom d-flex align-items-center gap-2">
              <div class="fw-semibold">Employers</div>
              <div class="ms-auto" style="width: 220px;">
                <input id="chat-search" type="text" class="form-control form-control-sm"
                       placeholder="Search employers…">
              </div>
            </div>

            <!-- List -->
            <div id="chat-user-list" class="list-group list-group-flush">
              @forelse($users as $u)
                @php
                  $initial = strtoupper(mb_substr($u->name ?? 'U', 0, 1));
                  $unread  = $u->unread_count ?? 0;     // optional: pass from controller
                  $online  = $u->is_online ?? false;    // optional: pass from controller
                  $preview = $u->last_message ?? null;  // optional: pass from controller
                  $when    = $u->last_message_at ?? null;
                @endphp

                <a href="{{ route('candidate.candidateChat', $u->id) }}"
                   class="list-group-item list-group-item-action py-3 d-flex align-items-center gap-3 user-row">
                  <!-- Avatar -->
                  <div class="position-relative">
                    <div class="rounded-circle d-inline-flex justify-content-center align-items-center"
                         style="width:42px;height:42px;background:#e6efff;">
                      <span class="fw-semibold">{{ $initial }}</span>
                    </div>
                    @if($online)
                      <span class="position-absolute translate-middle p-1 bg-success border border-light rounded-circle"
                            style="bottom:0; right:-2px;"></span>
                    @endif
                  </div>

                  <!-- Name + preview -->
                  <div class="flex-grow-1">
                    <div class="d-flex align-items-center">
                      <div class="fw-semibold me-2 user-name">{{ $u->name }}</div>
                      @if($unread > 0)
                        <span class="badge bg-primary rounded-pill">{{ $unread }}</span>
                      @endif
                      <div class="ms-auto small text-muted">
                        @if($when) {{ \Carbon\Carbon::parse($when)->format('d M, h:i A') }} @endif
                      </div>
                    </div>
                    @if($preview)
                      <div class="small text-muted text-truncate" style="max-width: 100%;">
                        {{ $preview }}
                      </div>
                    @else
                      <div class="small text-muted">Tap to view conversation</div>
                    @endif
                  </div>
                </a>
              @empty
                <div class="p-5 text-center">
                  <div class="fw-semibold mb-1">No employers found</div>
                  <div class="text-muted small">Try adjusting your search.</div>
                </div>
              @endforelse
            </div>

            <!-- Pagination (works if $users is paginated) -->
            @if(method_exists($users, 'links'))
              <div class="p-3 border-top">
                {{ $users->links() }}
              </div>
            @endif
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

{{-- Tiny client-side search --}}
<script>
  (function () {
    const q = document.getElementById('chat-search');
    const rows = document.querySelectorAll('#chat-user-list .user-row');

    if (!q) return;

    q.addEventListener('input', function () {
      const term = (this.value || '').toLowerCase().trim();
      rows.forEach(row => {
        const nameEl = row.querySelector('.user-name');
        const name = (nameEl?.textContent || '').toLowerCase();
        row.style.display = name.includes(term) ? '' : 'none';
      });
    });
  })();
</script>
@endsection
