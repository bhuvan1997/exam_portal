<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CandidateController;
use App\Http\Controllers\EmployerController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\MessageController;

use Illuminate\Support\Facades\Artisan;

Route::get('/run-optimize', function () {
    Artisan::call('optimize');
    return "Application optimized!";
});

// Home Page
Route::get('/', [LandingController::class, 'home'])->name('home');

// Candidate Dashboard (Role = 1)
Route::middleware(['auth', 'role:1'])->prefix('candidate')->controller(CandidateController::class)->name('candidate.')->group(function () {
    Route::get('/chat-users', [MessageController::class, 'candidateUsers'])->name('candidateUsers');
    Route::get('/chat/{userId}', [MessageController::class, 'candidateChat'])->name('candidateChat');
});

// Employer Dashboard (Role = 2)
Route::middleware(['auth', 'role:2'])->prefix('employer')->controller(EmployerController::class)->name('employer.')->group(function () {
    Route::get('/chat-users', [MessageController::class, 'employerUsers'])->name('employerUsers');
    Route::get('/chat/{userId}', [MessageController::class, 'employerChat'])->name('employerChat');
});

// 🔹 Common chat routes (both Candidate & Employer use them)
Route::middleware(['auth'])->group(function () {
    Route::post('/chat/send', [MessageController::class, 'send'])->name('send');
    Route::get('/chat/fetch/{userId}', [MessageController::class, 'fetch'])->name('fetch');
});
