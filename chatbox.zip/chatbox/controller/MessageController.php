<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MessageController extends Controller
{
    // Show all users for chatting
    // Candidate sees Employers
    public function candidateUsers()
    {
        $users = User::where('role', '2')->get();
        return view('candidate.chat.users', compact('users'));
    }

    // Employer sees Candidates
    public function employerUsers()
    {
        $users = User::where('role', '1')->get();
        return view('employer.chat.users', compact('users'));
    }

    // Candidate chat
    public function candidateChat($userId)
    {
        $user = User::where('role', 2)->findOrFail($userId);
        $allEmployers = User::where('role', 2)->orderBy('name')->get();

        $messages = Message::where(function ($q) use ($userId) {
            $q->where('from_user_id', Auth::id())
                ->where('to_user_id', $userId);
        })
            ->orWhere(function ($q) use ($userId) {
                $q->where('from_user_id', $userId)
                    ->where('to_user_id', Auth::id());
            })
            ->orderBy('id', 'desc')
            // ->take(50)
            ->get()
            ->reverse();

        return view('candidate.chat.index', compact('messages', 'user', 'allEmployers'));
    }


    // Employer chat
    // MessageController.php

    public function employerChat($userId)
    {
        // Selected candidate
        $user = User::where('role', 1)->findOrFail($userId);

        // Sidebar list of candidates (you can later filter to “recent”)
        $allCandidates = User::where('role', 1)->orderBy('name')->get();

        // Last 50 messages between employer (me) and candidate ($userId)
        $messages = Message::where(function ($q) use ($userId) {
            $q->where('from_user_id', Auth::id())
                ->where('to_user_id', $userId);
        })
            ->orWhere(function ($q) use ($userId) {
                $q->where('from_user_id', $userId)
                    ->where('to_user_id', Auth::id());
            })
            ->orderBy('id', 'desc')
            // ->take(50)
            ->get()
            ->reverse();

        return view('employer.chat.index', compact('messages', 'user', 'allCandidates'));
    }


    // Send a message
    public function send(Request $request)
    {
        $request->validate([
            'to_user_id' => 'required|exists:users,id',
            'message' => 'required|string|max:1000'
        ]);

        $msg = Message::create([
            'from_user_id' => Auth::id(),
            'to_user_id'   => $request->to_user_id,
            'message'      => $request->message,
        ]);

        return response()->json($msg);
    }

    // Fetch messages (for refresh)
    public function fetch(Request $request, $userId)
    {
        $query = Message::where(function ($q) use ($userId) {
            $q->where('from_user_id', Auth::id())
                ->where('to_user_id', $userId);
        })->orWhere(function ($q) use ($userId) {
            $q->where('from_user_id', $userId)
                ->where('to_user_id', Auth::id());
        });


        if ($request->filled('after_id')) {
            $query->where('id', '>', (int) $request->after_id);
        }

        return response()->json($query->orderBy('id', 'asc')->get());
    }
}
