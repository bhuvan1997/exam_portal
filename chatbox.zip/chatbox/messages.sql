-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2025 at 08:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_user_id` bigint(20) UNSIGNED NOT NULL,
  `to_user_id` bigint(20) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(4, 7, 10, 'hi', 0, '2025-08-27 01:17:31', '2025-08-27 01:17:31'),
(5, 7, 10, 'hello', 0, '2025-08-27 01:39:06', '2025-08-27 01:39:06'),
(6, 7, 9, 'hi', 0, '2025-08-27 01:53:46', '2025-08-27 01:53:46'),
(7, 9, 7, 'hello bhuvan', 0, '2025-08-27 01:54:23', '2025-08-27 01:54:23'),
(8, 7, 9, 'hello', 0, '2025-08-27 02:00:10', '2025-08-27 02:00:10'),
(9, 9, 7, 'yes', 0, '2025-08-27 02:00:19', '2025-08-27 02:00:19'),
(10, 7, 9, 'hi gourav', 0, '2025-08-27 02:40:13', '2025-08-27 02:40:13'),
(11, 9, 7, 'yes', 0, '2025-08-27 02:40:27', '2025-08-27 02:40:27'),
(12, 7, 9, 'can you confirm my interview process ?', 0, '2025-08-27 02:40:50', '2025-08-27 02:40:50'),
(13, 9, 7, 'yes i\'ll sure definitely', 0, '2025-08-27 02:41:03', '2025-08-27 02:41:03'),
(14, 7, 9, 'ee', 0, '2025-08-27 02:43:50', '2025-08-27 02:43:50'),
(15, 9, 7, 'wwww', 0, '2025-08-27 02:44:03', '2025-08-27 02:44:03'),
(16, 7, 9, 'ok', 0, '2025-08-27 02:46:20', '2025-08-27 02:46:20'),
(17, 9, 7, 'ss', 0, '2025-08-27 02:46:35', '2025-08-27 02:46:35'),
(18, 7, 9, 'ok done', 0, '2025-08-27 02:47:43', '2025-08-27 02:47:43'),
(19, 9, 7, 'sss', 0, '2025-08-27 02:47:51', '2025-08-27 02:47:51'),
(20, 7, 9, 'ok', 0, '2025-08-27 02:48:55', '2025-08-27 02:48:55'),
(21, 9, 7, 'welcome', 0, '2025-08-27 02:54:35', '2025-08-27 02:54:35'),
(22, 7, 9, 'hi', 0, '2025-08-27 02:55:55', '2025-08-27 02:55:55'),
(23, 7, 9, 'ok', 0, '2025-08-27 02:56:34', '2025-08-27 02:56:34'),
(24, 7, 9, 'hi gourav', 0, '2025-08-27 03:53:57', '2025-08-27 03:53:57'),
(25, 7, 9, 'sss', 0, '2025-08-27 03:54:09', '2025-08-27 03:54:09'),
(26, 7, 9, 'hiii gourav mahipal', 0, '2025-08-27 04:17:42', '2025-08-27 04:17:42'),
(27, 9, 7, 'ddd', 0, '2025-08-27 04:17:53', '2025-08-27 04:17:53'),
(28, 9, 7, 'sdijsijsjis', 0, '2025-08-27 04:18:07', '2025-08-27 04:18:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `messages_from_user_id_foreign` (`from_user_id`),
  ADD KEY `messages_to_user_id_foreign` (`to_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_from_user_id_foreign` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_to_user_id_foreign` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
